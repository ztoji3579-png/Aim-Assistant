# Carrom Aim Assistant (Android starter)

This is a native Kotlin Android Studio starter project for a Carrom Pool aiming assistant.

## Included
- Runtime request for Android's MediaProjection screen-capture consent.
- Foreground service and ImageReader pipeline that consumes live screen frames in memory.
- Floating, non-interactive overlay using `SYSTEM_ALERT_WINDOW` permission.
- Physics helper functions for direct aiming, mirrored-target bank shots, and simplified coin collision simulation.
- No network access, no screenshot storage, and no root requirement.

## Important current limitation
The overlay paths are intentionally labelled as demo paths. This starter does **not yet detect the board, striker, coins, or pockets from the captured images** and therefore does not yet compute a real shot from Carrom Pool. The ImageReader callback currently consumes each frame; the next milestone is computer-vision detection and board calibration, followed by connecting detected positions to `AimPhysics`.

The physics helpers are approximations, not a reverse-engineered model of Carrom Pool's proprietary physics. Tune radii, friction, rebounds, and collision response against test recordings before trusting a prediction.

## Build an APK
1. Open this folder in Android Studio (Giraffe or newer; recent stable recommended).
2. Let Android Studio install the required Android SDK and Gradle components.
3. Sync Gradle.
4. Build > Build APK(s).
5. Debug APK output is usually `app/build/outputs/apk/debug/app-debug.apk`.

This execution environment has Java but no Android SDK or Gradle installation, so an APK could not be compiled here. Build it in Android Studio on a computer with the Android SDK installed.

## Test on Android
1. Install the debug APK.
2. Open the app and allow “display over other apps”.
3. Tap “Show demo trajectories” to test overlay rendering.
4. Tap “Start live screen capture” and accept Android's system prompt.
5. Open Carrom Pool. Current lines remain illustrative until detection is implemented.
6. Return to the app and tap “Stop overlay / capture”.

## Planned next milestone: automatic detection
- Crop/rectify the board using corner and line detection.
- Detect pockets and circular pieces using image processing; track detections between frames.
- Add a manual board calibration UI and confidence indicators.
- Generate candidate direct, bank, and combination shots and score them by target-to-pocket geometry.
- Draw only predictions with adequate detection confidence.
