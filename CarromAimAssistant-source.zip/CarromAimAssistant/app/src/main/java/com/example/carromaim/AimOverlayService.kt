package com.example.carromaim

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.WindowManager

class AimOverlayService : Service() {
    companion object {
        const val ACTION_DEMO = "com.example.carromaim.DEMO"
        const val ACTION_CAPTURE = "com.example.carromaim.CAPTURE"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_RESULT_DATA = "resultData"
        private const val CHANNEL = "carrom_aim_capture"
        private const val NOTIFICATION_ID = 41
    }

    private lateinit var wm: WindowManager
    private var overlay: AimView? = null
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CAPTURE -> {
                startForeground(NOTIFICATION_ID, notification())
                showOverlay()
                val code = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                val data = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java) else @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_RESULT_DATA)
                if (data != null && code == Activity.RESULT_OK) startCapture(code, data)
            }
            ACTION_DEMO -> showOverlay()
            else -> showOverlay()
        }
        return START_NOT_STICKY
    }

    private fun showOverlay() {
        if (overlay != null || !Settings.canDrawOverlays(this)) return
        val view = AimView(this)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        wm.addView(view, params)
        overlay = view
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(resultCode, data)
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels.coerceAtLeast(1)
        val height = metrics.heightPixels.coerceAtLeast(1)
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        reader?.setOnImageAvailableListener({ r ->
            // Consume frames so the capture pipeline is live. Vision detection is the next implementation step.
            val image = r.acquireLatestImage()
            image?.close()
        }, null)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, null)
        display = projection?.createVirtualDisplay("CarromAimCapture", width, height, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface, null, null)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL, "Carrom Aim screen capture", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        return builder.setContentTitle("Carrom Aim Assistant")
            .setContentText("Screen capture active; trajectory overlay is illustrative")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setOngoing(true).build()
    }

    override fun onDestroy() {
        display?.release(); display = null
        reader?.close(); reader = null
        projection?.stop(); projection = null
        overlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        overlay = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private class AimView(context: Context) : View(context) {
        private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(35, 220, 140); strokeWidth = 5f; style = Paint.Style.STROKE }
        private val bounce = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(255, 190, 45); strokeWidth = 4f; style = Paint.Style.STROKE; pathEffect = android.graphics.DashPathEffect(floatArrayOf(14f, 10f), 0f) }
        private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 34f; setShadowLayer(5f, 1f, 1f, Color.BLACK) }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat(); val h = height.toFloat()
            // Demonstration only: these coordinates are not derived from captured pixels yet.
            val sx = w * .50f; val sy = h * .78f
            val tx = w * .67f; val ty = h * .42f
            canvas.drawLine(sx, sy, tx, ty, line)
            canvas.drawCircle(tx, ty, 22f, line)
            val path = Path().apply { moveTo(sx, sy); lineTo(w * .82f, h * .64f); lineTo(w * .77f, h * .30f) }
            canvas.drawPath(path, bounce)
            canvas.drawText("DEMO PATHS — not auto-detected", 24f, 60f, label)
        }
    }
}
