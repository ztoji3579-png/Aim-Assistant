package com.example.carromaim

import kotlin.math.*

data class Vec2(val x: Float, val y: Float) {
    operator fun plus(o: Vec2) = Vec2(x + o.x, y + o.y)
    operator fun minus(o: Vec2) = Vec2(x - o.x, y - o.y)
    operator fun times(s: Float) = Vec2(x * s, y * s)
    fun length() = hypot(x, y)
    fun normalized(): Vec2 { val n = length().coerceAtLeast(0.0001f); return Vec2(x / n, y / n) }
    fun dot(o: Vec2) = x * o.x + y * o.y
}

data class Coin(val center: Vec2, val radius: Float, val isQueen: Boolean = false)
data class Board(val left: Float, val top: Float, val right: Float, val bottom: Float, val pocketRadius: Float)
data class PathResult(val points: List<Vec2>, val pocketed: Boolean, val collisions: Int, val label: String)

/** Simple 2D predictor. Coordinates should be in a normalized board coordinate space. */
object AimPhysics {
    fun directPath(striker: Vec2, target: Coin, board: Board, samples: Int = 30): PathResult {
        val d = (target.center - striker).normalized()
        val end = target.center - d * (target.radius + 0.02f)
        val pts = (0..samples).map { i -> striker + (end - striker) * (i.toFloat() / samples) }
        return PathResult(pts, false, 0, "Direct contact")
    }

    fun bankPath(start: Vec2, target: Vec2, board: Board, bounceOnVerticalWall: Boolean = true, samples: Int = 40): PathResult {
        // Mirror the target across a selected wall, then aim at its image.
        val mirrored = if (bounceOnVerticalWall) {
            val reflectRight = target.x > (board.left + board.right) / 2f
            Vec2(if (reflectRight) 2f * board.right - target.x else 2f * board.left - target.x, target.y)
        } else {
            val reflectBottom = target.y > (board.top + board.bottom) / 2f
            Vec2(target.x, if (reflectBottom) 2f * board.bottom - target.y else 2f * board.top - target.y)
        }
        val dir = (mirrored - start).normalized()
        val points = mutableListOf(start)
        var p = start
        var v = dir
        repeat(samples) {
            val step = 0.025f
            var next = p + v * step
            if (bounceOnVerticalWall && (next.x <= board.left || next.x >= board.right)) {
                v = Vec2(-v.x, v.y); next = p + v * step
            } else if (!bounceOnVerticalWall && (next.y <= board.top || next.y >= board.bottom)) {
                v = Vec2(v.x, -v.y); next = p + v * step
            }
            p = next; points.add(p)
        }
        return PathResult(points, false, 0, "Bank-shot estimate")
    }

    /** Lightweight collision simulation for a striker and stationary target coins. */
    fun simulate(strikerStart: Vec2, aimDirection: Vec2, coins: List<Coin>, board: Board,
                 strikerRadius: Float = 0.018f, speed: Float = 0.018f, maxSteps: Int = 500): PathResult {
        var p = strikerStart
        var v = aimDirection.normalized() * speed
        val points = mutableListOf(p)
        var hits = 0
        var pocketed = false
        repeat(maxSteps) {
            p += v
            if (p.x < board.left + strikerRadius || p.x > board.right - strikerRadius) v = Vec2(-v.x, v.y)
            if (p.y < board.top + strikerRadius || p.y > board.bottom - strikerRadius) v = Vec2(v.x, -v.y)
            p = Vec2(p.x.coerceIn(board.left + strikerRadius, board.right - strikerRadius), p.y.coerceIn(board.top + strikerRadius, board.bottom - strikerRadius))
            for (coin in coins) {
                val delta = p - coin.center
                val minDist = strikerRadius + coin.radius
                if (delta.length() < minDist) {
                    hits++
                    val n = delta.normalized()
                    // Equal-mass, stationary-object approximation: striker reflects its normal component.
                    v = v - n * (2f * v.dot(n))
                    p = coin.center + n * minDist
                }
            }
            val corners = listOf(Vec2(board.left, board.top), Vec2(board.right, board.top), Vec2(board.left, board.bottom), Vec2(board.right, board.bottom))
            if (corners.any { (p - it).length() < board.pocketRadius }) pocketed = true
            points.add(p)
            v = v * 0.996f // approximate rolling friction
            if (v.length() < 0.001f || pocketed) return PathResult(points, pocketed, hits, if (pocketed) "Possible pocket" else "Estimated path")
        }
        return PathResult(points, pocketed, hits, "Estimated path")
    }
}
