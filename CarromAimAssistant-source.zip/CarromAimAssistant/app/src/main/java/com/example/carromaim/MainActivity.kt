package com.example.carromaim

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.graphics.Color

class MainActivity : Activity() {
    private val requestCapture = 7001
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(Color.rgb(246, 247, 245))
        }
        fun text(value: String, size: Float = 16f, bold: Boolean = false): TextView = TextView(this).apply {
            text = value; textSize = size; setTextColor(Color.rgb(28, 39, 35))
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 0, 0, (10 * resources.displayMetrics.density).toInt())
        }
        fun button(label: String, action: () -> Unit) = Button(this).apply {
            text = label; isAllCaps = false; setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = pad / 2 }
        }
        root.addView(text("Carrom Aim Assistant", 26f, true))
        root.addView(text("Live screen capture • trajectory overlay • shot simulator", 15f))
        root.addView(text("MVP status: the overlay and capture plumbing are included. Automatic coin recognition is not yet implemented, so the demo paths are illustrative until the board detector is added.", 14f))
        root.addView(button("1. Allow floating overlay") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else status.text = "Overlay permission already granted."
        })
        root.addView(button("2. Start live screen capture") {
            if (!Settings.canDrawOverlays(this)) {
                status.text = "Please allow floating overlay first, then return here."
            } else {
                val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(manager.createScreenCaptureIntent(), requestCapture)
            }
        })
        root.addView(button("Show demo trajectories (no capture)") {
            if (!Settings.canDrawOverlays(this)) {
                status.text = "Please allow floating overlay first."
            } else {
                val intent = Intent(this, AimOverlayService::class.java).setAction(AimOverlayService.ACTION_DEMO)
                startService(intent)
                status.text = "Demo overlay started. Paths are illustrative, not detected from the game."
            }
        })
        root.addView(button("Stop overlay / capture") {
            stopService(Intent(this, AimOverlayService::class.java))
            status.text = "Overlay stopped."
        })
        status = text("Ready. Grant overlay permission to begin.", 14f)
        root.addView(status)
        root.addView(text("How to test", 18f, true))
        root.addView(text("• Grant overlay permission.\n• Start capture and approve Android's screen-sharing prompt.\n• Open Carrom Pool; the overlay displays a demo trajectory.\n• Stop capture from this app.\n\nPrivacy: Android displays a system capture prompt. This starter keeps frames in memory and does not upload or save screenshots."))
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
    }

    @Deprecated("Deprecated in Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCapture && resultCode == RESULT_OK && data != null) {
            val intent = Intent(this, AimOverlayService::class.java).apply {
                action = AimOverlayService.ACTION_CAPTURE
                putExtra(AimOverlayService.EXTRA_RESULT_CODE, resultCode)
                putExtra(AimOverlayService.EXTRA_RESULT_DATA, data)
            }
            startForegroundService(intent)
            status.text = "Screen capture started. Current paths are demo-only until vision detection is implemented."
        } else if (requestCode == requestCapture) status.text = "Screen capture permission was not granted."
    }
}
